fast-track-to-java

Please start sbt, run the 'man' or 'man e' command and follow the provided instructions
