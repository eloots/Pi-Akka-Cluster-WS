initial-state

# Initial State

In this step, we have all the code to drive the NeoPixel LED strip

You also need to shared library. Instructions for building this shared library can be found in the root README file
