base

This is the base project which aggregates all exercise projects and the 'common' project