# See https://gist.github.com/willurd/5720255 for other options if this doesn't work on your box
python -m SimpleHTTPServer 8000

