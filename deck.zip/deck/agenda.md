# Workshop Overview

- Brief intro to Clustering & Akka Clustering
- Description of the Raspberry Pi-based Cluster hardware
- Building & Running the _"Exercises"_
- ___Your experiments___


---

## Course Prerequisites


- Have the following installed on your laptop:
    - JDK 8
    - `sbt`
    - A (multi-window) terminal (such as iTerm2 on MacOS)
    - Cloned the [Pi-Akka-Cluster](https://github.com/lightbend/Pi-Akka-Cluster) repo
    - IntelliJ IDEA with Scala plugin
- Ability to physically connect you laptop to an Ethernet switch
- Set-up key-pair to allow for password-less login on the Pi's
- Respect for the cool hardware :-)
