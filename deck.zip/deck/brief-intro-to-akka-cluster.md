<!-- .slide: data-background="#1c3b48" data-state="h2Uppercase" -->
## A BRIEF INTRODUCTION TO AKKA CLUSTER

---

## Akka Cluster Definition

<blockquote>Akka Cluster provides a fault-tolerant decentralized peer-to-peer based cluster membership service with     no single point of failure or single point of bottleneck. It does this using gossip protocols and an automatic failure detector.</blockquote>

---

## Cluster Membership

- A cluster is made up from a set of actor systems forming member nodes:
    - An actor system can only be a member of one cluster at a time
    - All actor systems within a cluster must have the same name
- Member nodes can join or leave a cluster any time:
    - Joining can happen automatically using seed nodes, programatically or manually via command line or JMX
    - Shutting down an actor system makes it leave a cluster, but a member node can also leave programatically,  manually or by becoming unavailable

---

## Cluster Member States - I

![Cluster member states](images/member-states.png "Cluster member states")

---

## Cluster Member States - II

![Cluster member states - Weakly-up](images/member-states-weakly-up.png "Cluster member states")

---

## Seed Nodes and Automatic Downing

- Seed nodes are initial contact points for joining nodes:
  - An actor system tries to automatically join by contacting the seed nodes
  - In order to form a cluster, the first seed node must be started
  - Specify seed nodes via the *akka.cluster.seed-nodes* configuration setting
- Unavailable member nodes can be downed automatically:
  - Specify automatic downing via the *auto-down-unreachable-after* configuration setting
  - __Attention__: ___Automatic downing can lead to the formation of two (or more) separate clusters___

---

## Cluster Roles

``` no-highlight
-Dakka.cluster.roles.0=my-favorite-role
```

- Member nodes may perform different functions
- Therefore a member node can have zero or more roles:
  - Specify roles via the *akka.cluster.roles* configuration setting
  - The *Member* class lets you access the *roles* or ask *hasRole*

---

## Cluster Events

``` scala
   Cluster(system).subscribe(
      listener,
      InitialStateAsEvents,
      classOf[MemberUp]
   )
```

- You can subscribe an actor to cluster change notifications
- The most interesting event types are:
  - *ClusterDomainEvent*: base type
  - *MemberUp*: member status changed to *Up*
  - *UnreachableMember*: member considered unreachable by failure detector
  - *MemberRemoved*: member completely removed from the cluster
  - *MemberEvent*: member status change *Up*, *Removed*, ...
  - *CurrentClusterState*: current snapshot state of the cluster, sent to new subscribers, unless *InitialStateAsEvents* specified

---

## Akka Cluster Configuration

``` no-highlight
akka {
  actor {
    provider = akka.cluster.ClusterActorRefProvider
  }

  cluster {
    auto-down-unreachable-after = 5 seconds
    seed-nodes                  = [
      "akka.tcp://akkollect-system@"${HOSTNAME}":2551",
      "akka.tcp://akkollect-system@"${HOSTNAME}":2552"
    ]
  }
}
```

- In order to enable Akka Cluster use the *ClusterActorRefProvider*
- For the purpose of this training we want quick automatic downing

---

## Akka (Cluster) modules

- Akka Cluster Singleton
- Akka Cluster Sharding
- Akka Split Brain Resolver (not open source)
- Akka Persistence
- Akka Persistent Query
