<!-- .slide: data-background="#1c3b48" data-state="h2Uppercase" -->
## THE RASPBERRY PI-BASED CLUSTER HARDWARE

---

## The node hardware

- Raspberry Pi 3 Model B
    - 1GB RAM
    - 1 x 10/100Mpbs Ethernet
    - Wifi & Bluetooth
    - 4 x USB
    - 40-pin GPIO
    - Micro SD card reader - 16GB micro SD card
- The Status Display
    - 8 x RGB-LED strip
- USB 10-port power hub
- 2 x 5-port TP-Link Ethernet switch (10/100Mbps)
- 2 x USB to 9V converter
- Various cables

---

## The Cluster Status LED-strip

![LED-Legend](images/LED-legend.png)

---

## Workshop Cluster Hardware

- 5 clusters (`cluster-0` through `cluster-4`)
- Node numbering:
    - `cluster-0`: `node-0`, `node-1`, . . . , `node-4`
    - `cluster-1`: `node-5`, `node-6`, . . . , `node-9`
    - . . .
    - `cluster-4`: `node-20`, `node-21`, . . . , `node-24`

    
