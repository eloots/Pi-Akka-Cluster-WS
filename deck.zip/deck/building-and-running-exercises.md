<!-- .slide: data-background="#1c3b48" data-state="h2Uppercase" -->
## EDITING, BUILDING AND RUNNING THE EXERCISES

---

## Setting-up your laptop

- Allow for password-less ssh to Pi's: read instructions on the main README of this [GitHub repo](https://github.com/lightbend/Pi-Akka-Cluster)
- Add license file to this file in your home folder: `~/.lightbend/commercial.credentials`
- License file content will be provided during the workshop

---

## Editing and building the exercises

- Two possible ways to work
    - Work from the master repository
        - Solutions are given. Build and run ...
        - Less fun ... 
    - Work from a _Studentified_ version of the master repo
        - A better learning experience
        - The solution can be pulled at any time
        - Experiments can be saved for later use

---

## Work from the master repository

- Clone the master repository from the [GitHub repo](https://github.com/lightbend/Pi-Akka-Cluster)
    - This is a multi-project `sbt` build
    - The exercises are in folders named `exercise_ddd_...`
    - Common code and configuration settings are in the `common` project
- `cd` into the cloned repo an fire up `sbt`
- Select the project by running the `project` command
- Do a clean build by running `clean` and `assembly`
- Copy the generated uber-jar by using the `copy` command
    - Don't forget to set the `CLUSTER-NR` environment variable
- `ssh` to the different nodes using the `akkapi` account
- Run the code using the `run` command followed by the exercise number

---

## Work from a Studentified version

- Clone the studentified repo from the [GitHub repo](https://github/eloots/Pi-Akka-Cluster-studentified)
    - The code is in the `exercises` folder
    - Common code and configuration settings are in the `common` project
- `cd` into the cloned repo an fire up `sbt`
- A number of workshop/exercise specific commands are available as listed on the next slide. Among these, you can select an exercise and pull the solution
- Do a clean build by running `clean` and `assembly`
- Copy the generated uber-jar by using the `copySingle` command
    - Don't forget to set the `CLUSTER-NR` environment variable
- `ssh` to the different nodes using the `akkapi` account
- Run the code using the `runSingle` command followed by the exercise number

---

## Studentified project specific sbt commands

- `man e` - Displays current exercise instructions.
- `showExerciseID` - Displays the current exercise name.
- `listExercises` - Lists all exercises in course.
- `nextExercise` - Brings new tests and instructions into scope, while preserving your code.
- `prevExercise` - Reverts tests and instructions to the previous state, while preserving your code.
- `gotoExerciseNr <exercise Nr>` - Jump to exercise `Nr`, bring in tests for that exercise while preserving code.
- `pullSolution` - Overwrites your code with the official solution.
- `saveState` - Create a snapshot of your current code.
- `restoreState <exercise Id>` - Restore the code from a saved snapshot.
- `savedStates` - List all saved states.
